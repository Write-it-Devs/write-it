document.querySelectorAll(".swiper-slide").forEach(function(i) {
    i.onclick = () => {
        location.href = "edit-template.html"
    }
})
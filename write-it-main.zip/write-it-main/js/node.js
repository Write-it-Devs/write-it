const h4 = document.querySelector(".date");
const d = new Date();
const year = d.getFullYear();
// const searchbar = document.getElementById("search");s


h4.innerHTML = "&copy; Writeit " + year;
// searchbar.onfocus = () => {
//     location.href = "index.html#reader";
// }
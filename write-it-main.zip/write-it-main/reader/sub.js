AOS.init();
const el = document.querySelector("#sub");
el.className = "material-icons active";
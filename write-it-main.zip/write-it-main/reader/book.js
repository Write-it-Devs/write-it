const el = document.getElementById("book");
el.style.color = "rgba(0, 0, 255, .8)";
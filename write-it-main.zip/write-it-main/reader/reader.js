const el = document.getElementById("home");
el.style.color = "rgba(0, 0, 255, .8)";